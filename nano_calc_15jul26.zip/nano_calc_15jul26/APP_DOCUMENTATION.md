# nano_calc — Arduino Nano Calculator
## Application Documentation v30may26_v4

---

## 1. Overview

**nano_calc** is a scientific calculator firmware for Arduino Nano (ATmega328P) featuring a 5×5 matrix keypad, I2C LCD (16×2), serial command interface, and a lightweight programming mode.

| Specification | Value |
|---------------|-------|
| **MCU** | ATmega328P (Arduino Nano) |
| **Flash** | 32 KB |
| **SRAM** | 2 KB |
| **EEPROM** | 1 KB |
| **LCD** | I2C 16×2 (addr 0x27) |
| **Keypad** | 5×5 matrix (25 keys) |
| **Serial** | 9600 baud, line-oriented |
| **Libraries** | Wire, LiquidCrystal_I2C, Keypad, math.h |

---

## 2. Hardware Pinout

| Function | Pin | Notes |
|----------|-----|-------|
| Keypad Rows | D2–D6 | 5 rows |
| Keypad Cols | D7–D11 | 5 columns |
| Buzzer | D12 | `tone()` output |
| LED / OUT | D13 | Digital output, toggled via `OUT` |
| Analog A0 | A0 | General purpose ADC |
| Analog A1 | A1 | NTC 10kΩ thermistor input |
| I2C SDA | A4 | LCD data |
| I2C SCL | A5 | LCD clock |

**Keypad Layout (Row × Col):**

```
Row0:  A    M    X    Y    Z
Row1:  7    8    9    +    (
Row2:  4    5    6    -    )
Row3:  1    2    3    *    B
Row4:  0    .    =    /    C
```

- **A** = F1 modifier (Function Layer 1)
- **M** = F2 modifier (Function Layer 2 / Memory)
- **B** = Backspace / STOP program
- **C** = Clear All / STOP program
- **=** = Evaluate expression

---

## 3. Software Architecture

### 3.1 Execution Model

Single-threaded cooperative loop in `loop()`:

```
loop()
├── keypad.getKey() → event(key)
├── Serial.available() → processSerialChar()
├── millis() % 999 == 1 → analog/NTC polling
└── progRunning && !progPaused → runProgram() (one statement/iteration)
```

### 3.2 Major Modules

| Module | Functions | Responsibility |
|--------|-----------|----------------|
| **Input** | `event()`, `my_add_key()` | Keypad dispatch, modifier handling, token insertion |
| **Parser** | `parseExpression()` → `parseComparison()` → `parseTerm()` → `parseFactor()` → `parseNumber()` | Recursive-descent expression evaluator |
| **Solver** | `my_solve_equation()` | Evaluates `clc[]` buffer, updates X/Y/Z stack |
| **Display** | `my_print()`, `my_char2string()`, `my_check_mode()` | Token expansion, LCD rendering, mode auto-trigger |
| **Program** | `runProgram()`, `executeStatement()`, `progLen()` | Cooperative interpreter for PRG mode |
| **Serial** | `processSerialChar()`, `serialCommand()` | Line-oriented command interface |
| **Analog** | `my_ntc()` | Steinhart-Hart NTC temperature calculation |

### 3.3 Memory Map (SRAM ~2 KB)

| Buffer | Size | Purpose |
|--------|------|---------|
| `clc[64]` | 64 B | Raw input token buffer |
| `clcStr[64]` | 64 B | Rendered display string |
| `progBuf[256]` | 256 B | Program storage (PRG mode) |
| `serialBuf[96]` | 96 B | Serial command buffer |
| `xyz[3]` | 12 B | X, Y, Z register stack (float) |
| `mem[10]` | 20 B | Integer memory slots 0–9 |
| `loopStack[4]`, `loopPc[4]` | 8 B | Loop counters & return PCs |
| LCD line buffers | 34 B | `line1[17]`, `line2[17]` |

**Estimated SRAM usage:** ~500–600 bytes (well within 2 KB limit)

---

## 4. Operating Modes

### 4.1 Normal Calculator Mode (Default)
- Type expressions using keypad
- Press `=` to evaluate → result stored in **X**, previous X→Y, Y→Z
- Modifiers: **A** (F1), **M** (F2)

### 4.2 Function Layer 1 (F1) — Press **A** then key

| Key | Token | Display | Function |
|-----|-------|---------|----------|
| X | `$` | `RUN` | Run program |
| Y | `<` | `<` | IF less-than |
| Z | `>` | `>` | IF greater-than |
| 0 | `r` | `cos` | Cosine |
| 1 | `s` | `sin` | Sine |
| 2 | `v` | `tg` | Tangent |
| 3 | `u` | `ctg` | Cotangent |
| 4 | `p` | `pi` | π constant |
| 5 | `o` | `exp` | eˣ |
| 6 | `m` | `lg` | Log₁₀ |
| 7 | `q` | `sqrt` | Square root |
| 8 | `^` | `^` | Power |
| 9 | `n` | `ln` | Natural log |
| . | `,` | `,` | Reserved |
| = | `~` | `~` | Reserved |
| + | `@` | `LOOP` | Program loop |
| - | `#` | `IF` | Program if |
| * | `&` | `PAUSE` | Program pause |
| / | `w` | `GRAD` | Deg↔Rad toggle |
| ( | `:` | `PRG` | Enter PRG mode |
| ) | `;` | `END` | Program end |

### 4.3 Function Layer 2 (F2) — Press **M** then key

| Key | Token | Display | Function |
|-----|-------|---------|----------|
| X | `x` | `x` | Variable X |
| Y | `y` | `y` | Variable Y |
| Z | `z` | `z` | Variable Z |
| 0 | `a` | `a` | Mem[0] value |
| 1 | `b` | `b` | Mem[1] value |
| 2 | `c` | `c` | Mem[2] value |
| 3 | `d` | `d` | Mem[3] value |
| 4 | `e` | `e` | Mem[4] value |
| 5 | `f` | `f` | Mem[5] value |
| 6 | `g` | `g` | Mem[6] value |
| 7 | `h` | `A0` | Analog 0 |
| 8 | `i` | `A1` | Analog 1 / NTC |
| 9 | `j` | `OUT` | Toggle D13 |
| . | ` ` | ` ` | Space |
| = | `!` | `!=` | Not equal |
| + | `|` | `BUZ` | Buzzer |
| - | `_` | `_` | Reserved |
| * | `?` | `?` | Reserved |
| / | `%` | `%` | Reserved |
| ( | `{` | `{` | Programm mode |
| ) | `}` | `}` | Programm mode |

### 4.4 Programming Mode (PRG) — **F1 + (**
- Enter: `A` then `(` → shows `PRG> ` prompt
- Type program statements (appended to `progBuf[256]`)
- Special keys in PRG mode:
  - `C` → Clear buffer + exit
  - `B` → Backspace in buffer
  - `F1 + Y` → insert `<`
  - `F1 + Z` → insert `>`
  - `F1 + X` → Run program immediately
- Exit: `F1 + )` or `C`

### 4.5 Program Execution Mode
- Start: `F1 + X` (RUN) or serial `run`
- Interpreter runs cooperatively in `loop()`
- Statements separated by `;` or newline
- **PAUSE** → halts, shows `PAUSED - press key`, any key resumes
- **STOP**: Press `B` or `C` (no modifier) or serial `stop`
- Max loop nesting: 4 levels

### 4.6 Analog / NTC Mode
- Activate: `F2 + 7` (A0) or `F2 + 8` (A1) → inserts `A0`/`A1` token
- Or in program: `A0` / `A1` statement
- Or serial: `a0` / `a1`
- Polls every ~999 ms, updates LCD:
  - **A0**: Raw ADC 0–1023
  - **A1**: NTC 10kΩ → temperature °C (Steinhart-Hart)
- Exit: any keypress clears `analogMode`

### 4.7 Serial Command Mode (9600 baud, newline-terminated)

| Command | Action |
|---------|--------|
| `grad` | Set degree mode |
| `rad` | Set radian mode |
| `bs` | Backspace |
| `clear` / `cx` | Clear all |
| `a0` | Start analog A0 |
| `a1` | Start NTC A1 |
| `out` | Toggle D13 |
| `run` | Run program |
| `stop` | Stop program |
| `<expr>` | Evaluate expression, store in X |

---

## 5. Expression Language

### 5.1 Grammar (Precedence High → Low)

```
Expression    ::= Comparison (('+' | '-') Comparison)*
Comparison    ::= Term (('==' | '!=' | '<=' | '>=' | '<' | '>') Term)*
Number        ::= [+-]? digit+ ('.' digit+)?
Variable      ::= 'X'|'Y'|'Z'|'x'|'y'|'z' | 'a'..'g'
Function      ::= 'sin'|'cos'|'tg'|'ctg'|'sqrt'|'ln'|'exp'|'lg'|'abs' | 'pi'
```

### 5.2 Operators

| Symbol | Meaning | Associativity | Precedence |
|--------|---------|---------------|------------|
| `^` | Power | Right | Highest |
| `* /` | Mul, Div, | Left | Term |
| `+ -` | Add, Sub | Left | Expression |
| `< > <= >= == !=` | Comparison (→ 1.0/0.0) | Left | Comparison |

### 5.3 Functions (Parser Tokens)

| Token | Function | Display | Grad/Rad Aware |
|-------|----------|---------|---------------|
| `s` | sin | `sin` | Yes |
| `r` | cos | `cos` | Yes |
| `v` | tan | `tg` | Yes |
| `u` | cot | `ctg` | Yes |
| `q` | sqrt | `sqrt` | No |
| `n` | ln | `ln` | No |
| `o` | exp | `exp` | No |
| `m` | log10 | `lg` | No |
| `p` | π | `pi` | No |

### 5.4 Variables & Constants

| Symbol | Meaning | Type |
|--------|---------|------|
| `X` `Y` `Z` | Result registers (float) | Read/Write |
| `x` `y` `z` | Same as above (lowercase) | Read-only in expr |
| `a`–`g` | Memory slots 0–6 (int) | Read-only |
| `$` | Last answer (`lastAns`) | Read-only |
| `pi` | 3.14159... | Constant |

### 5.5 Operator Normalization (Invalid Sequence Handling)

When two operators appear consecutively without operand, the parser normalizes:

| Input | Normalized | Note |
|-------|------------|------|
| `*/` | `*` | |
| `/+` | `/` | |
| `-*` | `-` | |
| `*+` | `*` | |
| `//` | `/` | |
| `**` | `*` | Not power! Use `^` |
| `/-` | `/-` | **Kept** (unary minus) |
| `*-` | `*-` | **Kept** |
| `+-` | `+-` | **Kept** |
| `-+` | `-+` | **Kept** |
| `--` | `--` | **Kept** |
| (other) | (last) | Default: keep last |

---

## 6. Program Language (PRG Mode)

### 6.1 Statements

| Statement | Syntax | Description |
|-----------|--------|-------------|
| Assignment | `X=expr` / `x=expr` / `Y=...` / `Z=...` | Store in register |
| Output | `OUT` | Toggle D13 low/high |
| Loop | `LOOP n` | Start counted loop (n = expression) |
| End Loop/If | `END` | Close current LOOP or IF |
| Conditional | `IF expr` | If expr==0, skip to matching END |
| Pause | `PAUSE` | Sleep, seconds or Halt program, wait for key |
| Analog | `A0` / `A1` | Start analog/NTC monitor |
| Expression | `expr` | Evaluate, store in X |

### 6.2 Control Flow Details

- **LOOP n**: Pushes `n` to `loopStack`, saves return PC to `loopPc`. On `END`, decrements counter; if >0, jumps back to `loopPc`.
- **IF expr**: Evaluates `expr`. If 0 (false), scans forward for matching `END` (handles nested IF).
- **Nesting limit**: 4 levels (`loopStack[4]`)
- **Statement terminators**: `;` or newline

### 6.3 Example Program

```
X=0
LOOP 10
X=X+1
END
OUT
PAUSE=2
OUT
```

---

## 7. Display System

### 7.1 Rendering Pipeline

```
clc[] (raw tokens, cursor position)
    ↓ my_char2string()
clcStr[] (human-readable, tokens expanded with values)
    ↓ my_check_mode()
Auto-triggers modes (A0, A1, OUT, GRAD, RAD)
    ↓ my_print(arg)
Serial log: "arg clcStr"
LCD: 16×2, scrolls via set_cursor() if >31 chars
```

### 7.2 Token Expansion (my_char2string)

| Internal | Display |
|----------|---------|
| `X` `Y` `Z` | `X = 12.34` (with current value) |
| `x` `y` `z` | `x` `y` `z` |
| `a`–`g` | Memory value (integer) |
| `h` | `A0` |
| `i` | `A1` |
| `j` | `OUT` |
| `$` | `RUN` |
| `r` `s` `v` `u` | `cos` `sin` `tg` `ctg` |
| `p` `o` `m` `q` `n` | `pi` `exp` `lg` `sqrt` `ln` |
| `^` `@` `#` `&` `w` `:` `;` | `^` `LOOP` `IF` `PAUSE` `GRAD` `PRG` `END` |
| `!` `|` `j` | `!=` `BUZ` `OUT` |

### 7.3 Mode Auto-Trigger (my_check_mode)

When `clcStr` starts with these prefixes, action fires **once** (tracked by `lastModeCmd`):

| Prefix | Action | Comment
|--------|--------|
| `A0` | Start analog A0 | stored in mem[7]
| `A1` | Start NTC A1 | stored in mem[8]
| `OUT` | Toggle D13, clear input | stored in mem[9]
| `GRAD` | Set degree, clear input |
| `RAD` | Set radian, clear input |

---

## 8. Key Functions Reference

### 8.1 Core

| Function | Signature | Description |
|----------|-----------|-------------|
| `setup()` | `void` | Hardware init, LCD, keypad, startup beep |
| `loop()` | `void` | Main event loop |
| `event(char k)` | `void` | Keypad dispatcher (mode-aware) |
| `my_print(const char*)` | `void` | Central display update + serial log |

### 8.2 Expression Evaluation

| Function | Signature | Description |
|----------|-----------|-------------|
| `my_solve_equation()` | `void` | Parses `clc[]`, updates X/Y/Z stack |
| `parseExpression()` | `float` | Entry point: handles `+` `-` |
| `parseComparison()` | `float` | Handles `< > <= >= == !=` |
| `parseTerm()` | `float` | Handles `*` `/` |
| `parseFactor()` | `float` | Handles unary, `()`, vars, funcs, `^`, numbers |
| `parseNumber()` | `float` | Parses float with optional sign, single decimal |
| `skipSpaces()` | `void` | Advances past spaces |

### 8.3 Program Interpreter

| Function | Signature | Description |
|----------|-----------|-------------|
| `runProgram()` | `void` | Fetches next statement, calls execute |
| `executeStatement()` | `void` | Dispatches PAUSE, OUT=, assignment, LOOP, END, IF, A0/A1, LIGHT, BLINK, bare expr |
| `progLen()` | `byte` | Returns `strlen(progBuf)` |

### 8.4 Display & Input

| Function | Signature | Description |
|----------|-----------|-------------|
| `my_char2string()` | `void` | Expands `clc[]` → `clcStr[]` |
| `my_check_mode()` | `void` | Auto-triggers mode commands from display |
| `my_add_key(char)` | `bool` | Inserts token with F1/F2 mapping + operator normalization |
| `clearAll()` | `void` | Resets input, analogMode, D13 |
| `backspace()` | `void` | Deletes last char |

### 8.5 Serial & Analog

| Function | Signature | Description |
|----------|-----------|-------------|
| `processSerialChar(char)` | `void` | Buffers chars, calls serialCommand on `\n` |
| `serialCommand(char*)` | `void` | Parses & executes serial commands |
| `my_ntc()` | `void` | Steinhart-Hart for 10k NTC on A1 |

---

## 9. Global State Variables

| Variable | Type | Purpose |
|----------|------|---------|
| `f1`, `f2` | `bool` | F1/F2 modifier active |
| `analogMode` | `bool` | Analog/NTC polling active |
| `degMode` | `bool` | `true`=GRAD, `false`=RAD |
| `clc[64]` | `char[]` | Raw input buffer |
| `cursor` | `int` | Position in `clc` |
| `clcStr[64]` | `char[]` | Rendered display string |
| `xyz[3]` | `float[]` | X, Y, Z register stack |
| `mem[10]` | `int[]` | Memory slots 0–9 |
| `analogPin` | `int` | A0 or A1 |
| `analogVal` | `int` | Last ADC reading |
| `temp` | `float` | Computed NTC temperature |
| `lastAns` | `float` | Last `=` result |
| `lastModeCmd[8]` | `char[]` | Prevents mode re-trigger |
| `progBuf[256]` | `char[]` | Program storage |
| `progMode` | `bool` | In PRG editing mode |
| `progRunning` | `bool` | Program executing |
| `progPc` | `byte` | Program counter (byte offset) |
| `loopStack[4]` | `byte[]` | Loop counters |
| `loopPc[4]` | `byte[]` | Loop return PCs |
| `loopDepth` | `byte` | Current nesting (0–4) |
| `progPaused` | `int` | PAUSE active |

---

## 10. Usage Scenarios

### 10.1 Basic Calculation
```
Keys:  2  +  3  *  4  =
Display: 2+3*4=14
X=14, Y=0, Z=0
```

### 10.2 Function (F1 Layer)
```
Keys:  A  1  (F1+1→sin)  3  0  =
Display: sin30=0.5
```

### 10.3 Variables (F2 Layer)
```
Keys:  M  X  (F2+X→x)  +  M  Y  (F2+Y→y)  =
Display: x+y=...
```

### 10.4 Memory Recall
- `M` `0` → inserts `a` (reads `mem[0]`)
- `M` `1` → inserts `b` (reads `mem[1]`)
- ... up to `M` `6` → `f` (`mem[6]`)

### 10.5 Programming
1. `A` `(` → Enter PRG (`PRG> `)
2. Type: `X=0` `LOOP 5` `X=X+1` `END` `OUT`
3. `A` `)` →  PRG (`Close loop`)
4. `A` `X` → Run (`RUNNING...` → `DONE`)

### 10.6 NTC Thermometer
```
Keys:  M  8  (F2+8→A1)  =
Display: temp = 23.45  NTC 10kOm
Updates ~1 Hz. Any key exits.
```

### 10.7 Serial Control
```
> rad
> 2*pi
> run
> out
> stop
```

---

## 11. Constraints & Limits

| Limit | Value |
|-------|-------|
| Max expression length | 63 chars (`clc[64]`) |
| Max program length | 255 chars (`progBuf[256]`) |
| Max loop nesting | 4 levels |
| Max serial command | 95 chars |
| LCD visible | 16×2 (scrolls at >31 chars) |
| Number precision | IEEE 754 float (~7 digits) |
| Integer memory | 10 slots (int16) |
| Analog poll rate | ~1 Hz (`millis() % 999`) |
| Buzzer | Fixed tones on D12 |
| Persistence | None (RAM only, lost on reset) |

---

## 13. File Structure

```
nano_calc_30may26_v4/
├── nano_calc_30may26_v4.ino    # Main sketch (single file)
├── PLAN.md                      # Development plan & keymap tables
├── APP_DOCUMENTATION.md         # This file
└── nano_calc_30may26_v4.ino.bk  # Backup
```

---

## 14. Version History

| Version | Date | Notes |
|---------|------|-------|
| 30may26_v4 | 2026-05-30 | Current: PRG mode, NTC, serial, F1/F2 layers, operator normalization |
| 12jul26 | 2026-07-12 | Build tag in startup string |

---

## 15. License

```
2026 hjltu
PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND
```

---

