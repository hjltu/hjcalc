# nano_calc Architecture Refactor — Implementation Plan

**Version:** 15jul26_refactor  
**Base:** nano_calc_15jul26.ino (948 lines)  
**Strategy:** Incremental, non-breaking phases. Each phase compiles and passes regression tests.

---

## Phase 1: Foundation — Config, Tokens, State, Display, Commands ✅ **COMPLETE**
**Target:** Replace globals with `AppState`, add `TOKEN_TABLE`, pure `DisplayEngine::render()`, `Command` dispatch table.

### Completed
- [x] `Config` struct with all #defines, pin mappings, NTC constants
- [x] `TokenType` enum (all tokens from docs §5.3, §6.1)
- [x] `TokenDef` struct + `TOKEN_TABLE[]` (single source of truth)
- [x] Helper: `find_token_by_key()`, `find_token_by_serial()`, `get_display_string()`
- [x] `AppState` struct consolidating all 20+ globals
- [x] `Mode` enum: NORMAL, F1_PENDING, F2_PENDING, ANALOG, PRG_EDIT, PRG_RUN
- [x] Global instance `AppState g_state` (temporary bridge)
- [x] `DisplayEngine` namespace:
  - [x] `DisplayLines` struct
  - [x] `expand_tokens()` — token expansion using `TOKEN_TABLE`
  - [x] `render(const AppState&)` — **pure function**, no side effects
  - [x] `update_lcd()` — LCD output only
  - [x] `show_message()` — modal messages
- [x] `Command` registry + `COMMAND_TABLE[]`
- [x] Handlers: rad, grad, out, run, stop, a0, a1, prog, load, expr
- [x] `dispatch_command()` — single dispatch point for serial + keypad special keys
- [x] `AnalogModule::poll()` — NTC/ADC polling
- [x] `KeypadHandler` namespace using `TOKEN_TABLE` for key mapping
- [x] `SerialHandler` namespace
- [x] New `setup()` / `loop()` wiring modular handlers
- [x] Legacy bridge: all original functions kept for Phase 1 compatibility

### File Created
- `nano_calc_15jul26_refactor.ino` (498 lines vs original 948)

### Verification Needed
- [ ] Compiles on Arduino IDE 1.8.x / 2.x
- [ ] Fits in Flash (< 30 KB) and RAM (< 1.8 KB)
- [ ] All existing keypad sequences work (F1, F2, normal)
- [ ] Serial commands work: rad, grad, run, stop, out, a0, a1, prog, load, expressions
- [ ] LCD display correct (scroll, status, mode)
- [ ] Serial output matches LCD
- [ ] No crash on edge cases (empty input, long input, div/0)

---

## Phase 2: Parser & Interpreter
**Target:** Token-based parser + bytecode interpreter. Replace `evaluateExpression()` and `runProgram()`.

### Tasks
- [ ] `Token` struct (type, value, text)
- [ ] `tokenize(const char*, Token*, max, AppState&)` → token count
- [ ] `Parser` struct with precedence climbing using `TOKEN_TABLE` precedence
- [ ] Right-associative `^` handling
- [ ] Functions: sin, cos, tan, cot, sqrt, ln, exp, log10, abs, pi
- [ ] Variables: X,Y,Z, x,y,z, mem[0-9], A0, A1, OUT, lastAns
- [ ] Error reporting with position
- [ ] `evaluate_tokens(Token*, count, AppState&)` → float
- [ ] `OpCode` enum, `Instruction` struct
- [ ] `Program::compile(const char*, AppState&)` → bytecode
- [ ] Jump offset calculation for LOOP/IF/END
- [ ] `Program::step(AppState&)` → bool (stack-based eval)
- [ ] Loop frame management
- [ ] PAUSE handling via `pause_until`
- [ ] Switch calculator `=` key to new tokenizer/parser/evaluator
- [ ] Switch serial expressions to new evaluator
- [ ] Switch program execution to `Program::compile()` + `step()`
- [ ] Verify all expression examples from APP_DOCUMENTATION.md §10 produce identical results

---

## Phase 3: Input & Polish
**Target:** Complete migration, remove legacy code.

### Tasks
- [ ] `KeypadHandler` class using `TOKEN_TABLE` (replace namespace functions)
- [ ] `AnalogModule` class
- [ ] Remove all legacy global functions (Section 13)
- [ ] Remove `extern` bridge declarations
- [ ] Single `AppState state` instance in main (no `g_state` global)
- [ ] Delete dead code

---

## Phase 4: Validation & Documentation
**Target:** Full regression test per checklist.

### Regression Tests (from PLAN.md)
- [ ] Compiles on Arduino IDE 1.8.x / 2.x
- [ ] Fits in Flash (< 30 KB) and RAM (< 1.8 KB)
- [ ] All existing keypad sequences still work
- [ ] New feature works via keypad AND serial
- [ ] LCD display correct (scroll, status, mode)
- [ ] Serial output matches LCD
- [ ] No crash on edge cases (empty input, long input, div/0)

### Functional Tests (from APP_DOCUMENTATION.md §10)
- [ ] 10.1 Basic Calculation
- [ ] 10.2 Function (F1 Layer)
- [ ] 10.3 Variables (F2 Layer)
- [ ] 10.4 Memory Recall
- [ ] 10.5 Programming
- [ ] 10.6 NTC Thermometer
- [ ] 10.7 Serial Control

### Documentation
- [ ] Update APP_DOCUMENTATION.md if any behavior changed (should be none)
- [ ] Update version header in .ino

---

## Current Status

| Phase | Status | Notes |
|-------|--------|-------|
| 1: Foundation | ✅ **DONE** | `nano_calc_15jul26_refactor.ino` created |
| 2: Parser/Interpreter | ⏳ PENDING | |
| 3: Input/Polish | ⏳ PENDING | |
| 4: Validation | ⏳ PENDING | |

---

## Rollback Plan
If any phase breaks functionality:
1. `cp nano_calc_15jul26_refactor.ino nano_calc_15jul26_refactor.ino.bk.phaseN`
2. Revert to previous working version
3. Debug incrementally

---

## File Structure After Refactor
```
nano_calc_15jul26_refactor/
├── nano_calc_15jul26_refactor.ino   # Single file, modular sections
├── PLAN.md                           # This file
├── APP_DOCUMENTATION.md              # Unchanged (behavior spec)
├── AGENT.md                          # Unchanged (rules)
├── ARCHITECTURE_ANALYSIS.md          # Analysis doc
└── nano_calc_15jul26.ino             # Original (backup)
```