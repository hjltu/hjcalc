# nano_calc Architecture Analysis & Improvement Proposal

**Current Version:** 15jul26 (948 lines, single .ino)
**Goal:** Improve structure, maintainability, extensibility — **without changing behavior**

---

## 1. Current Architecture Assessment

### 1.1 Structural Issues

| Issue | Impact | Location |
|-------|--------|----------|
| **Monolithic single file** (948 lines) | Hard to navigate, review, test | Entire .ino |
| **20+ global variables** scattered at top | Tight coupling, hidden dependencies | Lines 46-77 |
| **3 giant switch statements** (keypad handlers) | Hard to extend, easy to miss cases | `handleF1Key`, `handleF2Key`, `my_char2string` |
| **Parser & interpreter share logic but duplicated** | Bugs fixed in one place missed in other | `parsePrimary` vs `executeStatement` |
| **Token chars as magic values** ('s','c','r','t','v','u'...) | Undocumented, error-prone | Throughout parser/display |
| **Mode state scattered across 6+ bools** | Implicit state machine, race conditions | `f1,f2,analogMode,degMode,progMode,progRunning` |
| **Display logic mixed with token expansion** | Can't test display independently | `my_char2string()` |
| **Program interpreter mutates progBuf** | Destroys source, fragile | `executeStatement()` modifies buffer |
| **Parser uses `char* + int& pos` pattern** | Not encapsulatable, error-prone | All parse* functions |
| **Magic numbers throughout** (999, 300, 50, 800, 1500) | Unexplained, hard to tune | #defines at top + inline |
| **No error handling strategy** | Silent NaN returns, crashes on div/0 | Parser returns NAN |
| **Serial & LCD output scattered** | Inconsistent formatting, hard to redirect | `Serial.print` + `lcd.print` everywhere |

### 1.2 Coupling Diagram (Current)

```
loop()
├── processKeypad() → handleKey() → {handleNormalKey, handleF1Key, handleF2Key}
│   └── my_add_key() → operator normalization
├── processSerial() → processSerialChar() → serialCommand()
│   └── evaluateExpression() → parser chain
├── my_ntc() (analog poll)
├── runProgram() → executeStatement()
│   └── evaluateExpression() → parser chain (DUPLICATE)
└── updateDisplay() → my_char2string() → my_check_mode() → my_check_mode_cmd()
    └── (modifies global state: analogMode, degMode, progMode, d13state)
```

**Key Problem:** Display path (`updateDisplay` → `my_check_mode`) **mutates global state** — a render function should be pure.

---

## 2. Proposed Architecture (Modular Single-File)

### 2.1 Module Decomposition (within single .ino)

```
┌─────────────────────────────────────────────────────────────┐
│                       nano_calc.ino                          │
├─────────────────────────────────────────────────────────────┤
│  CONFIG        │  #defines, constants, pin mappings          │
│  TOKENS        │  TokenType enum, token tables, precedence   │
│  STATE         │  AppState struct (all globals → one struct) │
│  PARSER        │  Parser struct + tokenize/parse/eval        │
│  INTERPRETER   │  Program struct + compile/execute           │
│  INPUT         │  KeypadHandler + ModifierState              │
│  DISPLAY       │  DisplayEngine (LCD + Serial)               │
│  ANALOG        │  NTC/ADC polling                            │
│  COMMANDS      │  CommandRegistry (serial + keypad cmds)     │
│  MAIN          │  setup() + loop() wiring modules together   │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 Key Design Principles

1. **Single State Struct** — All globals → `AppState` struct passed by reference
2. **Token-Based Parser** — Lex → Token[] → Parse → AST/Eval (not char* + index)
3. **Immutable Program Buffer** — Interpreter reads `progBuf`, never mutates it
4. **Pure Display** — `render()` takes state, returns strings; never mutates state
5. **Command Registry** — `struct Command { const char* name; void(*fn)(AppState&, const char* args); }`
6. **Explicit Mode Enum** — Replace 6 bools with `enum Mode { NORMAL, F1, F2, ANALOG, PRG_EDIT, PRG_RUN }`
7. **Centralized Token Definitions** — One `TokenDef` table drives keypad, parser, display, serial

---

## 3. Detailed Module Specifications

### 3.1 CONFIG — Centralized Constants

```cpp
// All magic numbers in one place
struct Config {
  static constexpr uint16_t BUF_CLC = 64;
  static constexpr uint16_t BUF_CLCSTR = 64;
  static constexpr uint16_t BUF_PROG = 256;
  static constexpr uint16_t BUF_SERIAL = 96;
  static constexpr uint16_t ANALOG_POLL_MS = 999;
  static constexpr uint16_t SCROLL_MS = 300;
  static constexpr uint16_t KEY_DEBOUNCE_MS = 50;
  static constexpr uint16_t MODE_DISPLAY_MS = 800;
  static constexpr uint16_t STARTUP_DELAY_MS = 1500;
  static constexpr uint8_t LOOP_MAX_DEPTH = 4;
  
  // NTC
  static constexpr float NTC_R25 = 10000.0;
  static constexpr float NTC_BETA = 3950.0;
  static constexpr float NTC_T0 = 298.15;
  
  // Pins
  static constexpr uint8_t PIN_BUZZER = 12;
  static constexpr uint8_t PIN_LED = 13;
  static constexpr uint8_t PIN_ROWS[5] = {2,3,4,5,6};
  static constexpr uint8_t PIN_COLS[5] = {7,8,9,10,11};
  static constexpr uint8_t LCD_ADDR = 0x27;
  static constexpr uint8_t LCD_COLS = 16;
  static constexpr uint8_t LCD_ROWS = 2;
};
```

### 3.2 TOKENS — Single Source of Truth

```cpp
enum TokenType : uint8_t {
  // Literals
  TOK_NUMBER, TOK_PI, TOK_LASTANS,
  // Variables
  TOK_X, TOK_Y, TOK_Z, TOK_x, TOK_y, TOK_z,
  // Memory
  TOK_MEM0, TOK_MEM1, TOK_MEM2, TOK_MEM3, TOK_MEM4, TOK_MEM5, TOK_MEM6,
  // Functions (F1 layer)
  TOK_SIN, TOK_COS, TOK_TAN, TOK_COT, TOK_SQRT, TOK_LN, TOK_EXP, TOK_LOG10, TOK_ABS,
  // Operators
  TOK_ADD, TOK_SUB, TOK_MUL, TOK_DIV, TOK_POW,
  // Comparisons
  TOK_LT, TOK_GT, TOK_LE, TOK_GE, TOK_EQ, TOK_NE,
  // Program control
  TOK_RUN, TOK_LOOP, TOK_IF, TOK_PAUSE, TOK_END, TOK_PRG,
  // Analog/IO
  TOK_A0, TOK_A1, TOK_OUT, TOK_BUZ, TOK_LIGHT, TOK_BLINK,
  // Mode
  TOK_GRAD, TOK_RAD,
  // Punctuation
  TOK_LPAREN, TOK_RPAREN, TOK_COMMA, TOK_SEMI, TOK_ASSIGN,
  // Special
  TOK_EOF, TOK_ERROR
};

// Single token definition table drives EVERYTHING:
struct TokenDef {
  TokenType type;
  char key;           // Keypad key (unmodified)
  char f1_key;        // With F1 modifier
  char f2_key;        // With F2 modifier
  const char* display;// Display string
  const char* serial; // Serial command alias
  uint8_t precedence; // Parser precedence
  bool right_assoc;   // For ^ 
};

// Example entries:
const TokenDef TOKEN_TABLE[] = {
  {TOK_SIN,   0, '1', 0, "sin", "sin",  10, false},
  {TOK_COS,   0, '0', 0, "cos", "cos",  10, false},
  {TOK_TAN,   0, '2', 0, "tg",  "tan",  10, false},
  {TOK_COT,   0, '3', 0, "ctg", "cot",  10, false},
  {TOK_SQRT,  0, '7', 0, "sqrt","sqrt", 10, false},
  {TOK_LN,    0, '9', 0, "ln",  "ln",   10, false},
  {TOK_EXP,   0, '5', 0, "exp", "exp",  10, false},
  {TOK_LOG10, 0, '6', 0, "lg",  "log10",10, false},
  {TOK_PI,    0, '4', 0, "pi",  "pi",   10, false},
  {TOK_POW,   '^','8', 0, "^",   "^",    9,  true},   // right-assoc
  {TOK_MUL,   '*', 0,  0, "*",   "*",    8,  false},
  {TOK_DIV,   '/', 0,  0, "/",   "/",    8,  false},
  {TOK_ADD,   '+', 0,  0, "+",   "+",    7,  false},
  {TOK_SUB,   '-', 0,  0, "-",   "-",    7,  false},
  {TOK_LT,    0,  'Y', 0, "<",   "<",    6,  false},
  {TOK_GT,    0,  'Z', 0, ">",   ">",    6,  false},
  {TOK_LE,    0,  0,   0, "<=",  "<=",   6,  false},
  {TOK_GE,    0,  0,   0, ">=",  ">=",   6,  false},
  {TOK_EQ,    0,  0,   0, "==",  "==",   6,  false},
  {TOK_NE,    '=', '!', 0, "!=",  "!=",   6,  false},
  {TOK_LOOP,  0,  '+', 0, "LOOP","LOOP", 0,  false},
  {TOK_IF,    0,  '-', 0, "IF",  "IF",   0,  false},
  {TOK_PAUSE, 0,  '*', 0, "PAUSE","PAUSE",0, false},
  {TOK_END,   0,  ')', ';', "END", "END", 0,  false},
  {TOK_PRG,   0,  '(', ':', "PRG", "PRG",  0,  false},
  {TOK_RUN,   0,  'X', '$', "RUN", "RUN",  0,  false},
  {TOK_A0,    0,  0,   '7', "A0",  "A0",   0,  false},
  {TOK_A1,    0,  0,   '8', "A1",  "A1",   0,  false},
  {TOK_OUT,   0,  0,   '9', "OUT", "OUT",  0,  false},
  {TOK_GRAD,  0,  '/', 'w', "GRAD","GRAD", 0,  false},
  {TOK_RAD,   'M','C', 'M', "RAD", "rad",  0,  false},
  {TOK_LPAREN, '(', 0,  0, "(",  "(",    0,  false},
  {TOK_RPAREN, ')', 0,  0, ")",  ")",    0,  false},
  {TOK_ASSIGN,'=', 0,  0, "=",  "=",    0,  false},
  {TOK_X,     'X', 0,  'X', "x",  "x",    0,  false},
  {TOK_Y,     'Y', 0,  'Y', "y",  "y",    0,  false},
  {TOK_Z,     'Z', 0,  'Z', "z",  "z",    0,  false},
  {TOK_MEM0,  '0', 0,  '0', "mem[0]","a",0, false},
  // ... etc for MEM1-MEM6
  {TOK_EOF, 0, 0, 0, "", "", 0, false}
};
```

**Benefits:**
- Keypad handlers → lookup in table
- Parser → precedence from table
- Display → display string from table
- Serial → command alias from table
- **Single source of truth** — add token in one place

---

### 3.3 STATE — Single AppState Struct

```cpp
enum Mode {
  MODE_NORMAL,
  MODE_F1_PENDING,    // A pressed, waiting for key
  MODE_F2_PENDING,    // M pressed, waiting for key
  MODE_ANALOG,        // Continuous A0/A1 polling
  MODE_PRG_EDIT,      // Editing program buffer
  MODE_PRG_RUN        // Program executing
};

struct LoopFrame {
  uint8_t count = 0;
  uint16_t return_pc = 0;
};

struct AppState {
  // Mode
  Mode mode = MODE_NORMAL;
  bool deg_mode = false;          // true = GRAD (200 grad = 180 deg)
  
  // Input buffers
  char input_buf[Config::BUF_CLC] = "";
  uint8_t input_len = 0;
  char display_buf[Config::BUF_CLCSTR] = "";
  
  // Registers
  float xyz[3] = {0,0,0};         // X, Y, Z stack
  float last_ans = 0;
  int16_t mem[10] = {0};          // Memory 0-9
  
  // Analog
  bool analog_active = false;
  uint8_t analog_pin = 0;         // 0=A0, 1=A1
  int analog_val = 0;
  float ntc_temp = 0;
  uint32_t last_analog_read = 0;
  
  // Program
  char prog_buf[Config::BUF_PROG] = "";
  uint16_t prog_pc = 0;
  LoopFrame loop_stack[Config::LOOP_MAX_DEPTH];
  uint8_t loop_depth = 0;
  uint32_t pause_until = 0;
  bool prog_paused = false;
  
  // Serial
  char serial_buf[Config::BUF_SERIAL] = "";
  uint8_t serial_len = 0;
  
  // Display
  uint32_t last_scroll = 0;
  uint8_t scroll_pos = 0;
  char last_mode_cmd[8] = "";
  
  // Hardware
  bool d13_state = false;
};
```

**All global variables eliminated.** Pass `AppState&` to every module function.

---

### 3.4 PARSER — Token-Based Recursive Descent

```cpp
struct Token {
  TokenType type;
  float value;        // For TOK_NUMBER
  const char* text;   // Original text for errors
};

struct Parser {
  const Token* tokens;
  uint8_t token_count;
  uint8_t pos = 0;
  bool error = false;
  const char* error_msg = nullptr;
  
  // Parsing functions return float, set error on failure
  float parse_expression();
  float parse_comparison();
  float parse_term();
  float parse_factor();
  float parse_power();      // Right-associative ^
  float parse_primary();    // Numbers, vars, funcs, parens
  float parse_number();
  
  Token peek() const;
  Token consume();
  bool match(TokenType t);
  void expect(TokenType t, const char* msg);
};

// Tokenizer: char* → Token[]
uint8_t tokenize(const char* input, Token* out_tokens, uint8_t max_tokens, AppState& state);

// Evaluator: Token[] + AppState → float
float evaluate_tokens(const Token* tokens, uint8_t count, AppState& state);
```

**Advantages over current:**
- No `char* + int& pos` threading through call stack
- Tokens carry type info — no `switch(c)` on magic chars
- Error position tracking for better messages
- Reusable for both calculator expressions AND program statements
- Testable in isolation

---

### 3.5 INTERPRETER — Compile to Bytecode

```cpp
enum OpCode : uint8_t {
  OP_NOP, OP_PUSH_CONST, OP_PUSH_VAR, OP_PUSH_MEM,
  OP_STORE_VAR, OP_STORE_MEM,
  OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_POW,
  OP_LT, OP_GT, OP_LE, OP_GE, OP_EQ, OP_NE,
  OP_CALL_SIN, OP_CALL_COS, OP_CALL_TAN, OP_CALL_COT,
  OP_CALL_SQRT, OP_CALL_LN, OP_CALL_EXP, OP_CALL_LOG10, OP_CALL_ABS,
  OP_JMP, OP_JMP_IF_ZERO, OP_JMP_IF_NOT_ZERO,
  OP_LOOP_BEGIN, OP_LOOP_END,
  OP_PAUSE, OP_OUT, OP_A0, OP_A1, OP_LIGHT, OP_BLINK,
  OP_END
};

struct Instruction {
  OpCode op;
  union {
    float fval;
    uint8_t u8val;
    uint16_t u16val;
  };
};

struct Program {
  Instruction code[Config::BUF_PROG / 4];  // Estimate
  uint16_t length = 0;
  uint16_t pc = 0;
  LoopFrame loops[Config::LOOP_MAX_DEPTH];
  uint8_t loop_depth = 0;
  uint32_t pause_until = 0;
  
  void compile(const char* source, AppState& state);
  bool step(AppState& state);  // Execute one instruction
  void reset();
};
```

**Benefits:**
- Source buffer never modified
- Faster execution (no string parsing at runtime)
- Easier debugging (can print bytecode)
- Clean separation: compile once, run many
- Loop/IF handling via jump offsets

---

### 3.6 INPUT — Keypad Handler with Modifier State

```cpp
struct KeyEvent {
  char key;
  bool f1_active;
  bool f2_active;
};

class KeypadHandler {
  Keypad keypad;
  uint32_t last_key_time = 0;
  bool f1_pending = false;
  bool f2_pending = false;
  
public:
  KeypadHandler() : keypad(makeKeymap(Config::KEYMAP), Config::PIN_ROWS, Config::PIN_COLS, 5, 5) {}
  
  bool poll(KeyEvent& out_event) {
    char key = keypad.getKey();
    if (!key) return false;
    if (millis() - last_key_time < Config::KEY_DEBOUNCE_MS) return false;
    last_key_time = millis();
    
    if (f1_pending) {
      out_event = {key, true, false};
      f1_pending = false;
      return true;
    }
    if (f2_pending) {
      out_event = {key, false, true};
      f2_pending = false;
      return true;
    }
    if (key == 'A') { f1_pending = true; return false; }
    if (key == 'M') { f2_pending = true; return false; }
    
    out_event = {key, false, false};
    return true;
  }
  
  void cancel_modifiers() { f1_pending = f2_pending = false; }
};
```

**Key mapping via TOKEN_TABLE** — no giant switch statements.

---

### 3.7 DISPLAY — Pure Render Function

```cpp
struct DisplayLines {
  char line1[17];
  char line2[17];
  char status_char;  // '1','2','A','P','R',' '
};

class DisplayEngine {
  LiquidCrystal_I2C lcd;
  uint32_t last_scroll = 0;
  uint8_t scroll_pos = 0;
  
public:
  DisplayEngine() : lcd(Config::LCD_ADDR, Config::LCD_COLS, Config::LCD_ROWS) {}
  
  void begin() {
    lcd.init();
    lcd.backlight();
    lcd.clear();
  }
  
  // Pure function: state → display lines (no side effects)
  static DisplayLines render(const AppState& state) {
    DisplayLines out = {};
    // Build display from state.input_buf + state.xyz + state.mem + state.mode
    // Token expansion using TOKEN_TABLE
    // Scroll logic for >32 chars
    return out;
  }
  
  void update(const DisplayLines& lines) {
    // LCD output only
    // Scroll handling for long lines
    // Status char at (15,1)
  }
  
  void show_mode_message(const char* msg, uint16_t duration_ms) {
    lcd.clear();
    lcd.print(msg);
    delay(duration_ms);
  }
};
```

**Critical:** `render()` is **pure** — never calls `my_check_mode()` or mutates state. Mode triggers move to COMMAND layer.

---

### 3.8 COMMANDS — Unified Dispatch

```cpp
using CommandFn = void(*)(AppState&, const char* args);

struct Command {
  const char* name;
  CommandFn handler;
  const char* help;
};

void cmd_rad(AppState& s, const char* args) { s.deg_mode = false; }
void cmd_grad(AppState& s, const char* args) { s.deg_mode = true; }
void cmd_out(AppState& s, const char* args) { 
  s.d13_state = !s.d13_state; 
  digitalWrite(Config::PIN_LED, s.d13_state); 
  s.input_len = 0; s.input_buf[0] = '\0'; 
}
void cmd_run(AppState& s, const char* args) { 
  s.mode = MODE_PRG_RUN; s.prog_pc = 0; s.loop_depth = 0; s.pause_until = 0; 
}
void cmd_stop(AppState& s, const char* args) { 
  s.mode = MODE_NORMAL; s.pause_until = 0; 
}
void cmd_a0(AppState& s, const char* args) { s.analog_pin = 0; s.analog_active = true; s.last_analog_read = 0; }
void cmd_a1(AppState& s, const char* args) { s.analog_pin = 1; s.analog_active = true; s.last_analog_read = 0; }
void cmd_prog(AppState& s, const char* args) { s.mode = MODE_PRG_EDIT; s.prog_buf[0] = '\0'; s.prog_pc = 0; }
void cmd_load(AppState& s, const char* args) { strncpy(s.prog_buf, args, Config::BUF_PROG-1); }
void cmd_expr(AppState& s, const char* args) { 
  // Parse & evaluate, update XYZ stack
}

const Command COMMAND_TABLE[] = {
  {"rad",   cmd_rad,   "Set radian mode"},
  {"grad",  cmd_grad,  "Set grad (degree) mode"},
  {"out",   cmd_out,   "Toggle D13 output"},
  {"run",   cmd_run,   "Run program"},
  {"stop",  cmd_stop,  "Stop program"},
  {"a0",    cmd_a0,    "Start A0 analog monitor"},
  {"a1",    cmd_a1,    "Start A1 NTC monitor"},
  {"prog",  cmd_prog,  "Enter program edit mode"},
  {"load",  cmd_load,  "Load program: load <code>"},
  {nullptr, nullptr, nullptr}
};

// Dispatcher
void dispatch_command(AppState& state, const char* line) {
  // Split into cmd + args
  // Lookup in COMMAND_TABLE
  // If not found → treat as expression
}
```

**Keypad special keys (F1+X, F2+B, etc.)** also route through command table — **single dispatch point**.

---

### 3.9 ANALOG — NTC Polling Module

```cpp
struct AnalogModule {
  void poll(AppState& state) {
    if (!state.analog_active) return;
    if (millis() - state.last_analog_read < Config::ANALOG_POLL_MS) return;
    
    state.last_analog_read = millis();
    state.analog_val = analogRead(state.analog_pin ? A1 : A0);
    
    if (state.analog_pin == 1) {  // NTC on A1
      float v = state.analog_val * 5.0 / 1023.0;
      float r = Config::NTC_R25 * v / (5.0 - v);
      state.ntc_temp = 1.0 / (1.0/Config::NTC_T0 + log(r/Config::NTC_R25)/Config::NTC_BETA) - 273.15;
    }
  }
  
  void render_status(const AppState& state, char* line1, char* line2) {
    if (state.analog_pin == 0) {
      sprintf(line1, "A0 = %d", state.analog_val);
      sprintf(line2, "ADC 0-1023");
    } else {
      sprintf(line1, "temp = %.2f C", state.ntc_temp);
      sprintf(line2, "NTC 10kOm");
    }
  }
};
```

---

### 3.10 MAIN LOOP — Clean Wiring

```cpp
AppState state;
KeypadHandler keypad;
DisplayEngine display;
AnalogModule analog;
Program program;
Parser parser;

void setup() {
  Serial.begin(9600);
  pinMode(Config::PIN_BUZZER, OUTPUT);
  pinMode(Config::PIN_LED, OUTPUT);
  display.begin();
  display.show_mode_message("nano_calc v4", Config::STARTUP_DELAY_MS);
  Serial.println("nano_calc v4 ready");
}

void loop() {
  // 1. Input
  KeyEvent evt;
  if (keypad.poll(evt)) {
    handle_keypad(state, evt);
  }
  
  // 2. Serial
  while (Serial.available()) {
    char c = Serial.read();
    handle_serial_char(state, c);
  }
  
  // 3. Analog polling
  analog.poll(state);
  
  // 4. Program execution (cooperative)
  if (state.mode == MODE_PRG_RUN && (state.pause_until == 0 || millis() >= state.pause_until)) {
    state.pause_until = 0;
    if (!program.step(state)) {
      state.mode = MODE_NORMAL;
      display.show_mode_message("DONE", 1000);
    }
  }
  
  // 5. Display (pure render)
  auto lines = DisplayEngine::render(state);
  display.update(lines);
}
```

---

## 4. Migration Strategy (Non-Breaking)

### Phase 1: Foundation (No Behavior Change)
1. Create `Config`, `TokenDef`, `TOKEN_TABLE` — replace all #defines and magic chars
2. Create `AppState` struct — move all globals in, keep `extern AppState g_state` for gradual migration
3. Create `DisplayEngine::render()` — extract from `my_char2string` + `updateDisplay`, make pure
4. Create `Command` table + `dispatch_command()` — extract from `serialCommand` + keypad special keys

### Phase 2: Parser & Interpreter
5. Implement `Tokenizer` + `Parser` — test against current `evaluateExpression` outputs
6. Implement `Program::compile()` + bytecode `step()` — test against current `runProgram` behavior
7. Switch calculator `=` and serial expressions to new parser
8. Switch program execution to bytecode interpreter

### Phase 3: Input & Polish
9. Implement `KeypadHandler` using `TOKEN_TABLE`
10. Implement `AnalogModule`
11. Remove all legacy global functions, complete `AppState` migration
12. Delete dead code, verify flash/RAM usage

### Phase 4: Validation
13. Full regression test per PLAN.md checklist
14. Verify all keypad sequences, serial commands, program examples from APP_DOCUMENTATION.md

---

## 5. Risk Assessment & Mitigation

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Parser behavior mismatch | Medium | High | Extensive test vectors from current expr examples |
| Bytecode interpreter bugs | Medium | High | Run old & new interpreters in parallel, compare outputs |
| Display rendering diff | Low | Medium | Snapshot test LCD output strings |
| Keypad mapping errors | Low | High | Unit test `TOKEN_TABLE` lookups for every key combo |
| Flash/RAM increase | Low | Medium | Monitor after each phase; bytecode may increase flash slightly |
| Serial command breakage | Low | High | Dispatch table driven by same `TOKEN_TABLE` |

---

## 6. Expected Outcomes

| Metric | Current | Target |
|--------|---------|--------|
| Lines of code | ~950 | ~1100 (more verbose but structured) |
| Global variables | 20+ | 1 (`AppState state`) |
| Switch statements | 3 large | 0 (table-driven) |
| Parser functions | 7 (char* + int&) | 7 (Token[] + pos) + Tokenizer |
| Testable units | 0 | 6+ (Tokenizer, Parser, Interpreter, Display, Commands, Analog) |
| Adding new function | 5+ places | 1 place (TOKEN_TABLE) |
| Adding new command | 3+ places | 1 place (COMMAND_TABLE) |

---

## 7. Next Steps

**Awaiting your decision:**
1. **Proceed with Phase 1** — Create `ARCHITECTURE_REFACTOR_PLAN.md` with detailed file patches
2. **Focus on specific subsystem** — e.g., just Parser, or just Display
3. **Review only** — No implementation, just this analysis

The refactor is designed to be **incremental, non-breaking, and reversible** at each phase. All existing behavior preserved per APP_DOCUMENTATION.md.